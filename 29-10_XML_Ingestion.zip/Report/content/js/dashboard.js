/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 90.51433389544688, "KoPercent": 9.48566610455312};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5783666540927952, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.47, 500, 1500, "S01_ClinicalTrials_T037a_ClinicalTrial_AuditTrialHistory"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T022z_Save_TrialResult"], "isController": false}, {"data": [0.99, 500, 1500, "S01_ClinicalTrials_T030c_ClinicalTrial_Masters"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T001z_Login"], "isController": true}, {"data": [0.53, 500, 1500, "S01_ClinicalTrials_T008z_collaborator_keywordsearch"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T020z_person_keywordsearch"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T027e_api_ClinicalTrial_Id"], "isController": false}, {"data": [0.075, 500, 1500, "S01_ClinicalTrials_T006z_Drug_DrugPrimaryName"], "isController": false}, {"data": [0.76, 500, 1500, "S01_ClinicalTrials_T024a_ClinicalTrialAuditEntry_search"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T002e_UserGroup_GetUsersAndUserGroupByQueueId"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T009z_associatedCRO_keywordsearch"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T025z_Publish"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T029b_UserGroup_GetUsersAndUserGroupByQueueId"], "isController": false}, {"data": [0.99, 500, 1500, "S01_ClinicalTrials_T027b_authorization_user"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T011z_LocationCountry_keywordsearch"], "isController": false}, {"data": [0.99, 500, 1500, "S01_ClinicalTrials_T026b_Search"], "isController": false}, {"data": [0.74, 500, 1500, "S01_ClinicalTrials_T026e_ClinicalTrial_unlockdata"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T028z_Add_Note&Save"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T023z_Save_Note"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T014z_Save_TrialOutcome"], "isController": false}, {"data": [0.26, 500, 1500, "S01_ClinicalTrials_T037z_AuditTrial"], "isController": true}, {"data": [0.7327586206896551, 500, 1500, "S01_ClinicalTrials_T001e_Login_GetCredentialType"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T018z_Save_TreatmentPlan"], "isController": false}, {"data": [0.97, 500, 1500, "S01_ClinicalTrials_T027c_ClinicalTrial_lockdata"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T010z_tag_keywordsearch"], "isController": false}, {"data": [0.08, 500, 1500, "S01_ClinicalTrials_T034z_Save_TrialSummary"], "isController": false}, {"data": [0.3, 500, 1500, "S01_ClinicalTrials_T007z_sponsor_keywordsearch"], "isController": false}, {"data": [0.99, 500, 1500, "S01_ClinicalTrials_T004z_diseaseType_keywordsearch"], "isController": false}, {"data": [0.99, 500, 1500, "S01_ClinicalTrials_T029d_Search"], "isController": false}, {"data": [0.9396551724137931, 500, 1500, "S01_ClinicalTrials_T001g_Login_kmsi"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T002g_ClinicalTrialAdvanceSearch_advanceSearch"], "isController": false}, {"data": [0.8448275862068966, 500, 1500, "S01_ClinicalTrials_T001d_Login_authorize_1"], "isController": false}, {"data": [0.975, 500, 1500, "S01_ClinicalTrials_T003c_ClinicalTrial_Masters"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T026a_Tasks_GetMasterData"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T001i_Login_authorize_3-1"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T021z_Save_Association"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T038z_Publish"], "isController": false}, {"data": [0.92, 500, 1500, "S01_ClinicalTrials_T001i_Login_authorize_3-0"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T002z_ClinicalTrialsTab"], "isController": true}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T027z_Click_Edit_Icon_of_AnyClinicalTrial"], "isController": true}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T002c_Search"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T015z_Save_TrialTiming"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T036z_Save_Association"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T001a_Login_Landing"], "isController": false}, {"data": [0.9841269841269841, 500, 1500, "S01_ClinicalTrials_T017z_designKeywords_keywordsearch"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T002f_Tasks_GetMasterData"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T003b_authorization_user"], "isController": false}, {"data": [0.99, 500, 1500, "S01_ClinicalTrials_T031z_diseaseType_keywordsearch"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T019z_organization_keywordsearch"], "isController": false}, {"data": [0.45, 500, 1500, "S01_ClinicalTrials_T024b_ClinicalTrial_AuditTrialHistory"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T029c_Tasks_GetMasterData"], "isController": false}, {"data": [0.995, 500, 1500, "S01_ClinicalTrials_T002b_authorization_user"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T026f_ClinicalTrialAdvanceSearch_advanceSearch"], "isController": false}, {"data": [0.48, 500, 1500, "S01_ClinicalTrials_T029e_ClinicalTrial_unlockdata"], "isController": false}, {"data": [0.99, 500, 1500, "S01_ClinicalTrials_T029a_ClinicalTrialAdvanceSearch_advancedsearchcategory"], "isController": false}, {"data": [0.99, 500, 1500, "S01_ClinicalTrials_T005z_patientSegment_keywordsearch"], "isController": false}, {"data": [0.17, 500, 1500, "S01_ClinicalTrials_T024z_AuditTrial"], "isController": true}, {"data": [0.7931034482758621, 500, 1500, "S01_ClinicalTrials_T001i_Login_authorize_3"], "isController": false}, {"data": [0.95, 500, 1500, "S01_ClinicalTrials_T002d_ClinicalTrialAdvanceSearch_advancedsearchcategory"], "isController": false}, {"data": [0.025, 500, 1500, "S01_ClinicalTrials_T012z_Save_TrialSummary"], "isController": false}, {"data": [0.02, 500, 1500, "S01_ClinicalTrials_T032z_DrugPrimaryName"], "isController": false}, {"data": [0.7758620689655172, 500, 1500, "S01_ClinicalTrials_T001f_Login_login"], "isController": false}, {"data": [0.76, 500, 1500, "S01_ClinicalTrials_T037b_ClinicalTrialAuditEntry_search"], "isController": false}, {"data": [0.9051724137931034, 500, 1500, "S01_ClinicalTrials_T001c_Login_openid_configuration"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T016z_Save_PatientPopulation"], "isController": false}, {"data": [0.9137931034482759, 500, 1500, "S01_ClinicalTrials_T001h_Login_authorize_2"], "isController": false}, {"data": [0.97, 500, 1500, "S01_ClinicalTrials_T030z_NewClinicalTrial"], "isController": true}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T013z_Save_TrialObjective"], "isController": false}, {"data": [0.94, 500, 1500, "S01_ClinicalTrials_T003z_NewClinicalTrial"], "isController": true}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T030b_authorization_user"], "isController": false}, {"data": [0.98, 500, 1500, "S01_ClinicalTrials_T027d_ClinicalTrial_Masters"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T029f_ClinicalTrialAdvanceSearch_advanceSearch"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T035z_organization_keywordsearch"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T026d_ClinicalTrialAdvanceSearch_advancedsearchcategory"], "isController": false}, {"data": [0.19, 500, 1500, "S01_ClinicalTrials_T033z_sponsor_keywordsearch"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T029z_ClinicalTrials_LandingPage"], "isController": true}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T001b_Login_discovery_instance"], "isController": false}, {"data": [0.9137931034482759, 500, 1500, "S01_ClinicalTrials_T001h_Login_authorize_2-0"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T026c_UserGroup_GetUsersAndUserGroupByQueueId"], "isController": false}, {"data": [1.0, 500, 1500, "S01_ClinicalTrials_T001h_Login_authorize_2-1"], "isController": false}, {"data": [0.0, 500, 1500, "S01_ClinicalTrials_T026z_ClinicalTrials_LandingPage"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4744, 450, 9.48566610455312, 11044.256956155166, 5, 60053, 320.0, 49872.0, 56830.0, 60014.0, 3.8612175532382462, 37.16450906646479, 8.75738972150236], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["S01_ClinicalTrials_T037a_ClinicalTrial_AuditTrialHistory", 50, 0, 0.0, 1118.38, 92, 3316, 1013.0, 2073.3999999999996, 2865.2999999999984, 3316.0, 0.18754055564515826, 0.05272746676781354, 0.38663756545165395], "isController": false}, {"data": ["S01_ClinicalTrials_T022z_Save_TrialResult", 50, 3, 6.0, 50208.09999999999, 36798, 60004, 50282.5, 59153.7, 60001.45, 60004.0, 0.16646191850690317, 0.9543274792838141, 0.4431560898844421], "isController": false}, {"data": ["S01_ClinicalTrials_T030c_ClinicalTrial_Masters", 50, 0, 0.0, 190.58, 73, 825, 154.0, 325.5, 402.7499999999998, 825.0, 0.18831824276481313, 9.117585881357625, 0.38511448454472186], "isController": false}, {"data": ["S01_ClinicalTrials_T001z_Login", 58, 8, 13.793103448275861, 3412.741379310345, 2005, 5877, 3371.5, 4658.400000000001, 4975.399999999998, 5877.0, 0.387384619494797, 62.72462202865978, 8.041126846755986], "isController": true}, {"data": ["S01_ClinicalTrials_T008z_collaborator_keywordsearch", 100, 0, 0.0, 926.9100000000002, 132, 2122, 939.5, 1266.1000000000004, 1533.1999999999982, 2119.749999999999, 0.0936716378204858, 0.087711962816575, 0.20336075980343943], "isController": false}, {"data": ["S01_ClinicalTrials_T020z_person_keywordsearch", 55, 35, 63.63636363636363, 27748.672727272726, 11364, 32785, 30016.0, 30806.6, 31445.8, 32785.0, 0.05816013070167554, 1.9027006210576685, 0.12561947974441268], "isController": false}, {"data": ["S01_ClinicalTrials_T027e_api_ClinicalTrial_Id", 50, 0, 0.0, 28434.299999999992, 20549, 35946, 28275.0, 33875.4, 35030.85, 35946.0, 0.17001887209480251, 1.1383128761667547, 0.3475258800601867], "isController": false}, {"data": ["S01_ClinicalTrials_T006z_Drug_DrugPrimaryName", 100, 0, 0.0, 3707.9999999999995, 237, 6498, 3954.5, 5645.2, 5984.05, 6495.699999999999, 0.09366637349091765, 2.773578402032935, 0.20316638882878632], "isController": false}, {"data": ["S01_ClinicalTrials_T024a_ClinicalTrialAuditEntry_search", 50, 0, 0.0, 532.2799999999999, 120, 922, 499.5, 746.1999999999999, 849.1499999999997, 922.0, 0.1870669400338217, 4.853674631899029, 0.4349854403462235], "isController": false}, {"data": ["S01_ClinicalTrials_T002e_UserGroup_GetUsersAndUserGroupByQueueId", 100, 0, 0.0, 29.050000000000008, 14, 87, 27.0, 45.80000000000001, 49.89999999999998, 86.93999999999997, 0.09319308395485354, 0.07088589957187097, 0.19713431558067213], "isController": false}, {"data": ["S01_ClinicalTrials_T009z_associatedCRO_keywordsearch", 100, 0, 0.0, 30.54, 8, 206, 19.0, 66.70000000000002, 132.79999999999995, 205.7999999999999, 0.09381382271626666, 0.04882166613818213, 0.20339459747303087], "isController": false}, {"data": ["S01_ClinicalTrials_T025z_Publish", 50, 16, 32.0, 55797.16, 38667, 60016, 57387.5, 60003.0, 60008.05, 60016.0, 0.15419487147857464, 0.7303958085979061, 0.375112152676052], "isController": false}, {"data": ["S01_ClinicalTrials_T029b_UserGroup_GetUsersAndUserGroupByQueueId", 50, 0, 0.0, 48.160000000000004, 25, 101, 43.5, 74.69999999999999, 87.19999999999993, 101.0, 0.18774688715661095, 0.14281230990627677, 0.3971470041698584], "isController": false}, {"data": ["S01_ClinicalTrials_T027b_authorization_user", 50, 0, 0.0, 190.23999999999998, 79, 543, 174.0, 256.09999999999997, 399.8499999999997, 543.0, 0.18818995140935454, 1.17316218986296, 0.3841170092194257], "isController": false}, {"data": ["S01_ClinicalTrials_T011z_LocationCountry_keywordsearch", 100, 0, 0.0, 37.320000000000014, 19, 84, 33.5, 61.60000000000002, 70.89999999999998, 83.97999999999999, 0.09381549494240667, 0.053034155817686474, 0.20358145635890806], "isController": false}, {"data": ["S01_ClinicalTrials_T026b_Search", 50, 0, 0.0, 62.440000000000005, 16, 991, 40.0, 77.49999999999997, 118.14999999999972, 991.0, 0.18828562175678015, 1.4123113260391484, 0.3833929198486937], "isController": false}, {"data": ["S01_ClinicalTrials_T026e_ClinicalTrial_unlockdata", 50, 0, 0.0, 1327.02, 31, 12431, 97.5, 5603.399999999998, 8348.79999999998, 12431.0, 0.1882664799063186, 0.06285967722653352, 0.40229090301075754], "isController": false}, {"data": ["S01_ClinicalTrials_T028z_Add_Note&Save", 50, 38, 76.0, 58584.740000000005, 47759, 60024, 60002.0, 60016.9, 60020.7, 60024.0, 0.1532877149093763, 0.27778608086233536, 0.3980540651518774], "isController": false}, {"data": ["S01_ClinicalTrials_T023z_Save_Note", 50, 29, 58.0, 57655.43999999999, 46153, 60019, 60011.5, 60017.0, 60018.0, 60019.0, 0.1544998068752414, 0.4528262601390498, 0.4012015981073774], "isController": false}, {"data": ["S01_ClinicalTrials_T014z_Save_TrialOutcome", 100, 3, 3.0, 47434.85, 21320, 60017, 49420.0, 57548.7, 58454.25, 60016.95, 0.08780517787133907, 0.39627745832546746, 0.20957483909701155], "isController": false}, {"data": ["S01_ClinicalTrials_T037z_AuditTrial", 50, 0, 0.0, 1640.4600000000005, 684, 3720, 1486.5, 2941.6, 3483.3499999999985, 3720.0, 0.18720632008536608, 2.942656656588727, 0.8212580381713688], "isController": true}, {"data": ["S01_ClinicalTrials_T001e_Login_GetCredentialType", 58, 0, 0.0, 629.2758620689655, 189, 1569, 739.0, 867.3000000000001, 1118.9499999999996, 1569.0, 0.398787137052138, 0.8264465917451063, 1.481834773207005], "isController": false}, {"data": ["S01_ClinicalTrials_T018z_Save_TreatmentPlan", 63, 22, 34.92063492063492, 51418.650793650784, 28268, 60019, 53515.0, 60003.0, 60011.0, 60019.0, 0.06221128532465403, 0.24145253661578508, 0.15185698372286155], "isController": false}, {"data": ["S01_ClinicalTrials_T027c_ClinicalTrial_lockdata", 50, 0, 0.0, 188.28, 32, 1132, 99.0, 299.59999999999997, 1053.2499999999995, 1132.0, 0.18821616249830606, 0.06355236361856866, 0.40163196940922713], "isController": false}, {"data": ["S01_ClinicalTrials_T010z_tag_keywordsearch", 100, 0, 0.0, 25.930000000000007, 7, 162, 16.0, 37.0, 134.6999999999997, 161.88999999999993, 0.09381681516304893, 0.39431738797334104, 0.20211843352656472], "isController": false}, {"data": ["S01_ClinicalTrials_T034z_Save_TrialSummary", 50, 0, 0.0, 4456.04, 941, 28917, 2352.5, 16898.999999999978, 26342.6, 28917.0, 0.18834023286386392, 0.5577078004874245, 0.6402317220512512], "isController": false}, {"data": ["S01_ClinicalTrials_T007z_sponsor_keywordsearch", 100, 0, 0.0, 1489.5800000000006, 287, 2891, 1478.0, 2102.5, 2514.8, 2888.799999999999, 0.09365295212835699, 1.4744761024591393, 0.20478352061582436], "isController": false}, {"data": ["S01_ClinicalTrials_T004z_diseaseType_keywordsearch", 100, 0, 0.0, 62.63, 8, 1463, 21.0, 141.8, 170.89999999999998, 1457.9099999999974, 0.09414600161931123, 1.300010098629705, 0.2066890881253648], "isController": false}, {"data": ["S01_ClinicalTrials_T029d_Search", 50, 0, 0.0, 56.03999999999998, 12, 819, 36.0, 64.9, 152.19999999999933, 819.0, 0.1877983646518406, 1.408652792045237, 0.38240075208550084], "isController": false}, {"data": ["S01_ClinicalTrials_T001g_Login_kmsi", 58, 0, 0.0, 385.7241379310344, 172, 1454, 338.0, 819.3, 1097.45, 1454.0, 0.4008763987476069, 15.605668945211256, 1.3104889223336535], "isController": false}, {"data": ["S01_ClinicalTrials_T002g_ClinicalTrialAdvanceSearch_advanceSearch", 100, 100, 100.0, 30958.080000000005, 30048, 50040, 30134.5, 30437.3, 35091.399999999994, 50028.17999999999, 0.09064383408915183, 0.47737433592061046, 0.22387433671374404], "isController": false}, {"data": ["S01_ClinicalTrials_T001d_Login_authorize_1", 58, 0, 0.0, 516.2586206896551, 207, 1411, 436.5, 1077.6000000000001, 1358.95, 1411.0, 0.39723850747904227, 19.80108752602597, 0.5659204033340639], "isController": false}, {"data": ["S01_ClinicalTrials_T003c_ClinicalTrial_Masters", 100, 0, 0.0, 205.75, 59, 1516, 137.5, 333.9000000000001, 443.34999999999985, 1513.2299999999987, 0.09405258480016178, 4.553641311951262, 0.1923393728808777], "isController": false}, {"data": ["S01_ClinicalTrials_T026a_Tasks_GetMasterData", 50, 0, 0.0, 25.98, 16, 132, 21.0, 45.49999999999998, 53.34999999999999, 132.0, 0.1882820766759929, 0.17610625722532466, 0.38448891654020384], "isController": false}, {"data": ["S01_ClinicalTrials_T001i_Login_authorize_3-1", 50, 0, 0.0, 14.08, 11, 24, 13.0, 16.9, 18.89999999999999, 24.0, 0.34787448688513184, 0.9342808021115983, 0.1698605892993808], "isController": false}, {"data": ["S01_ClinicalTrials_T021z_Save_Association", 52, 8, 15.384615384615385, 52611.865384615376, 25662, 60053, 54283.0, 60012.7, 60013.35, 60053.0, 0.05563877594692917, 0.26963197825272844, 0.14371225825219344], "isController": false}, {"data": ["S01_ClinicalTrials_T038z_Publish", 50, 2, 4.0, 50837.840000000004, 33002, 60028, 52118.5, 58832.7, 59766.7, 60028.0, 0.15528384333723613, 0.5533624678174235, 0.3777613106810439], "isController": false}, {"data": ["S01_ClinicalTrials_T001i_Login_authorize_3-0", 50, 0, 0.0, 406.09999999999997, 256, 1003, 320.5, 807.6, 983.6999999999999, 1003.0, 0.34720775523242087, 2.4536602424551757, 1.1733791148459092], "isController": false}, {"data": ["S01_ClinicalTrials_T002z_ClinicalTrialsTab", 100, 100, 100.0, 31335.529999999995, 30198, 50243, 30441.5, 31291.4, 35402.649999999994, 50235.979999999996, 0.09054018082684916, 2.5756974975033544, 1.1568276463536753], "isController": true}, {"data": ["S01_ClinicalTrials_T027z_Click_Edit_Icon_of_AnyClinicalTrial", 50, 0, 0.0, 29000.179999999993, 20952, 36340, 28958.5, 34317.2, 35590.299999999996, 36340.0, 0.169849649090625, 10.476787471168022, 1.403648115687993], "isController": true}, {"data": ["S01_ClinicalTrials_T002c_Search", 100, 0, 0.0, 31.420000000000012, 12, 79, 29.0, 50.900000000000006, 55.94999999999999, 78.90999999999995, 0.0931741546076017, 0.6988889608076895, 0.1897240525120218], "isController": false}, {"data": ["S01_ClinicalTrials_T015z_Save_TrialTiming", 94, 2, 2.127659574468085, 45558.96808510639, 27713, 60013, 46003.0, 54481.0, 56741.0, 60013.0, 0.08431536818009762, 0.3900671955363085, 0.23261181933279632], "isController": false}, {"data": ["S01_ClinicalTrials_T036z_Save_Association", 50, 16, 32.0, 53147.12000000001, 35610, 60024, 53907.0, 60013.9, 60015.45, 60024.0, 0.15370143803065422, 0.39971980227847015, 0.375712958529815], "isController": false}, {"data": ["S01_ClinicalTrials_T001a_Login_Landing", 58, 0, 0.0, 68.39655172413795, 12, 412, 67.0, 82.9, 100.05, 412.0, 0.39519497421012106, 1.0613612060771447, 0.17984458787296526], "isController": false}, {"data": ["S01_ClinicalTrials_T017z_designKeywords_keywordsearch", 63, 0, 0.0, 78.01587301587301, 8, 1007, 27.0, 162.4, 383.59999999999945, 1007.0, 0.06398790933217953, 0.15102305113649636, 0.13850954257785958], "isController": false}, {"data": ["S01_ClinicalTrials_T002f_Tasks_GetMasterData", 100, 0, 0.0, 9.93, 5, 35, 8.5, 14.900000000000006, 16.0, 34.91999999999996, 0.09319421301214881, 0.08718027395370857, 0.19031095588838315], "isController": false}, {"data": ["S01_ClinicalTrials_T003b_authorization_user", 100, 0, 0.0, 143.77000000000007, 40, 258, 145.5, 199.00000000000006, 229.74999999999994, 257.9, 0.09406638641154609, 0.5864074644852358, 0.19200015062380124], "isController": false}, {"data": ["S01_ClinicalTrials_T031z_diseaseType_keywordsearch", 50, 0, 0.0, 55.260000000000005, 9, 602, 21.0, 150.2, 211.1499999999999, 602.0, 0.18792117834095665, 0.9862044713965173, 0.41274758027992736], "isController": false}, {"data": ["S01_ClinicalTrials_T019z_organization_keywordsearch", 55, 0, 0.0, 12285.363636363638, 5917, 16435, 12816.0, 15267.6, 15663.799999999997, 16435.0, 0.05910006715916723, 1.0899418653458697, 0.12909251175285427], "isController": false}, {"data": ["S01_ClinicalTrials_T024b_ClinicalTrial_AuditTrialHistory", 50, 0, 0.0, 1111.5600000000002, 516, 2030, 1133.5, 1515.3, 1813.5999999999992, 2030.0, 0.1872056191638648, 0.05264426767033839, 0.38594705333675294], "isController": false}, {"data": ["S01_ClinicalTrials_T029c_Tasks_GetMasterData", 50, 0, 0.0, 11.32, 5, 34, 9.0, 19.9, 28.699999999999974, 34.0, 0.18779342723004694, 0.17568221830985917, 0.38349105046948356], "isController": false}, {"data": ["S01_ClinicalTrials_T002b_authorization_user", 100, 0, 0.0, 169.27999999999994, 59, 1127, 152.5, 257.00000000000006, 319.4999999999999, 1120.5799999999967, 0.09309435392052907, 0.5803332926239481, 0.19001612219657987], "isController": false}, {"data": ["S01_ClinicalTrials_T026f_ClinicalTrialAdvanceSearch_advanceSearch", 50, 50, 100.0, 30134.879999999997, 30030, 30669, 30123.0, 30188.9, 30283.7, 30669.0, 0.16910802282281875, 0.8880681395411761, 0.41766709035272553], "isController": false}, {"data": ["S01_ClinicalTrials_T029e_ClinicalTrial_unlockdata", 50, 0, 0.0, 2851.939999999999, 44, 16160, 996.5, 8197.099999999999, 9728.199999999992, 16160.0, 0.18777791130873694, 0.06267821297395144, 0.4012469216158665], "isController": false}, {"data": ["S01_ClinicalTrials_T029a_ClinicalTrialAdvanceSearch_advancedsearchcategory", 50, 0, 0.0, 64.08, 5, 1168, 23.0, 142.8, 171.89999999999998, 1168.0, 0.18776521837094895, 1.4553381358199706, 0.38911774404784255], "isController": false}, {"data": ["S01_ClinicalTrials_T005z_patientSegment_keywordsearch", 100, 0, 0.0, 76.93000000000004, 11, 1364, 36.5, 161.70000000000002, 245.0499999999991, 1358.109999999997, 0.09414484938236271, 0.2687210269226026, 0.20714625014004046], "isController": false}, {"data": ["S01_ClinicalTrials_T024z_AuditTrial", 50, 0, 0.0, 1643.84, 920, 2626, 1592.5, 2289.7999999999997, 2378.7999999999997, 2626.0, 0.18666537245341766, 4.895747826981733, 0.8188849473976981], "isController": true}, {"data": ["S01_ClinicalTrials_T001i_Login_authorize_3", 58, 8, 13.793103448275861, 464.96551724137913, 268, 1115, 348.0, 933.1000000000001, 1003.6999999999999, 1115.0, 0.40272464049882306, 6.165561542661037, 1.4377239830334885], "isController": false}, {"data": ["S01_ClinicalTrials_T002d_ClinicalTrialAdvanceSearch_advancedsearchcategory", 100, 0, 0.0, 137.76999999999992, 5, 1226, 27.0, 558.1000000000006, 963.6499999999999, 1225.6999999999998, 0.09317441505102231, 0.7221781487827694, 0.19309123650368595], "isController": false}, {"data": ["S01_ClinicalTrials_T012z_Save_TrialSummary", 100, 0, 0.0, 3865.1199999999985, 878, 30111, 3283.0, 4275.2, 5863.6999999999925, 30067.28999999998, 0.09351623862725643, 0.3484384000937968, 0.3836631543915693], "isController": false}, {"data": ["S01_ClinicalTrials_T032z_DrugPrimaryName", 50, 0, 0.0, 4332.879999999999, 1316, 6954, 4600.0, 6234.0, 6629.949999999998, 6954.0, 0.18521331016932202, 5.484386778408943, 0.4017356281416808], "isController": false}, {"data": ["S01_ClinicalTrials_T001f_Login_login", 58, 0, 0.0, 559.7413793103448, 274, 1377, 481.0, 1058.0, 1228.7, 1377.0, 0.400187674219634, 16.427935816451853, 1.4301628845769052], "isController": false}, {"data": ["S01_ClinicalTrials_T037b_ClinicalTrialAuditEntry_search", 50, 0, 0.0, 522.06, 55, 1226, 488.5, 913.5999999999999, 1040.5499999999993, 1226.0, 0.18811702383818926, 2.9040822746263997, 0.43742719283311765], "isController": false}, {"data": ["S01_ClinicalTrials_T001c_Login_openid_configuration", 58, 0, 0.0, 302.4137931034483, 163, 890, 220.0, 869.4, 873.4499999999999, 890.0, 0.3962046328617588, 0.9968356997451994, 0.3241710656196845], "isController": false}, {"data": ["S01_ClinicalTrials_T016z_Save_PatientPopulation", 74, 66, 89.1891891891892, 54403.97297297297, 28697, 60018, 55074.5, 60013.0, 60014.0, 60018.0, 0.06875815341616523, 0.20166493454967124, 0.18813035082454033], "isController": false}, {"data": ["S01_ClinicalTrials_T001h_Login_authorize_2", 58, 0, 0.0, 424.0172413793104, 261, 1020, 347.0, 852.9000000000001, 992.1, 1020.0, 0.4010233008366176, 3.0053992839486967, 1.3125896684643574], "isController": false}, {"data": ["S01_ClinicalTrials_T030z_NewClinicalTrial", 50, 0, 0.0, 369.46000000000004, 208, 1107, 339.0, 488.4, 587.1499999999997, 1107.0, 0.18821545399449657, 10.285934123885292, 0.7690733423864966], "isController": true}, {"data": ["S01_ClinicalTrials_T013z_Save_TrialObjective", 100, 2, 2.0, 43678.29999999999, 10124, 60002, 47101.5, 56303.1, 57431.649999999994, 60001.99, 0.08947136737301328, 0.39691997473999624, 0.23434683049917868], "isController": false}, {"data": ["S01_ClinicalTrials_T003z_NewClinicalTrial", 100, 0, 0.0, 349.52, 118, 1695, 293.5, 507.6, 615.7499999999995, 1691.8899999999985, 0.09404763136338029, 5.139692032801933, 0.38429111245181236], "isController": true}, {"data": ["S01_ClinicalTrials_T030b_authorization_user", 50, 0, 0.0, 178.88000000000002, 80, 282, 171.5, 242.29999999999998, 256.7, 282.0, 0.18832888249407706, 1.174031954232315, 0.3844005833016313], "isController": false}, {"data": ["S01_ClinicalTrials_T027d_ClinicalTrial_Masters", 50, 0, 0.0, 187.35999999999999, 77, 633, 147.0, 340.0, 452.94999999999914, 633.0, 0.18800102272556363, 9.102242094321992, 0.3844657633687527], "isController": false}, {"data": ["S01_ClinicalTrials_T029f_ClinicalTrialAdvanceSearch_advanceSearch", 50, 50, 100.0, 30140.959999999995, 30042, 30315, 30136.5, 30227.2, 30254.6, 30315.0, 0.1691532189857573, 0.8847308032240604, 0.41777871693054575], "isController": false}, {"data": ["S01_ClinicalTrials_T035z_organization_keywordsearch", 50, 0, 0.0, 13033.840000000002, 8103, 19542, 12751.5, 15544.5, 17810.85, 19542.0, 0.17646456767945565, 3.2543995373981356, 0.38551648862862326], "isController": false}, {"data": ["S01_ClinicalTrials_T026d_ClinicalTrialAdvanceSearch_advancedsearchcategory", 50, 0, 0.0, 41.179999999999986, 6, 480, 20.5, 120.79999999999997, 172.99999999999983, 480.0, 0.1882863307889574, 1.459388227114738, 0.39019767828832663], "isController": false}, {"data": ["S01_ClinicalTrials_T033z_sponsor_keywordsearch", 50, 0, 0.0, 1583.0599999999997, 597, 2397, 1606.0, 2043.1, 2362.45, 2397.0, 0.18890022290226305, 2.974060605094639, 0.41305321201216516], "isController": false}, {"data": ["S01_ClinicalTrials_T029z_ClinicalTrials_LandingPage", 50, 50, 100.0, 33172.50000000001, 30221, 46499, 31429.5, 38476.1, 40104.399999999994, 46499.0, 0.1685067604912309, 3.7934294580148555, 2.1691296036046968], "isController": true}, {"data": ["S01_ClinicalTrials_T001b_Login_discovery_instance", 58, 0, 0.0, 60.48275862068964, 20, 223, 43.5, 164.0, 219.0, 223.0, 0.396358964546374, 0.7982370034408058, 0.2607378896960337], "isController": false}, {"data": ["S01_ClinicalTrials_T001h_Login_authorize_2-0", 58, 0, 0.0, 409.29310344827593, 248, 1007, 331.5, 836.3000000000001, 979.0, 1007.0, 0.4010732166071972, 2.5929499604977457, 1.1141748048225597], "isController": false}, {"data": ["S01_ClinicalTrials_T026c_UserGroup_GetUsersAndUserGroupByQueueId", 50, 0, 0.0, 50.84, 19, 460, 40.0, 71.5, 94.7999999999999, 460.0, 0.18828562175678015, 0.14322946086295069, 0.398286606725939], "isController": false}, {"data": ["S01_ClinicalTrials_T001h_Login_authorize_2-1", 58, 0, 0.0, 13.948275862068966, 11, 20, 13.0, 17.1, 20.0, 20.0, 0.4034249386168089, 0.4152440286153482, 0.19974262097531456], "isController": false}, {"data": ["S01_ClinicalTrials_T026z_ClinicalTrials_LandingPage", 50, 50, 100.0, 31642.339999999993, 30186, 42801, 30409.0, 35999.6, 39048.19999999998, 42801.0, 0.16898114508383155, 3.8076864664690713, 2.175236193395541], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 297, 66.0, 6.260539629005059], "isController": false}, {"data": ["504/Gateway Time-out", 145, 32.22222222222222, 3.0564924114671164], "isController": false}, {"data": ["Test failed: variable(token) expected not to contain /not_found/", 8, 1.7777777777777777, 0.16863406408094436], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4744, 450, "400/Bad Request", 297, "504/Gateway Time-out", 145, "Test failed: variable(token) expected not to contain /not_found/", 8, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T022z_Save_TrialResult", 50, 3, "504/Gateway Time-out", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T020z_person_keywordsearch", 55, 35, "400/Bad Request", 35, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T025z_Publish", 50, 16, "504/Gateway Time-out", 16, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T028z_Add_Note&Save", 50, 38, "504/Gateway Time-out", 38, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["S01_ClinicalTrials_T023z_Save_Note", 50, 29, "504/Gateway Time-out", 29, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["S01_ClinicalTrials_T014z_Save_TrialOutcome", 100, 3, "504/Gateway Time-out", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T018z_Save_TreatmentPlan", 63, 22, "400/Bad Request", 11, "504/Gateway Time-out", 11, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T002g_ClinicalTrialAdvanceSearch_advanceSearch", 100, 100, "400/Bad Request", 100, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T021z_Save_Association", 52, 8, "504/Gateway Time-out", 6, "400/Bad Request", 2, null, null, null, null, null, null], "isController": false}, {"data": ["S01_ClinicalTrials_T038z_Publish", 50, 2, "504/Gateway Time-out", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T015z_Save_TrialTiming", 94, 2, "504/Gateway Time-out", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["S01_ClinicalTrials_T036z_Save_Association", 50, 16, "504/Gateway Time-out", 16, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T026f_ClinicalTrialAdvanceSearch_advanceSearch", 50, 50, "400/Bad Request", 50, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T001i_Login_authorize_3", 58, 8, "Test failed: variable(token) expected not to contain /not_found/", 8, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T016z_Save_PatientPopulation", 74, 66, "400/Bad Request", 49, "504/Gateway Time-out", 17, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T013z_Save_TrialObjective", 100, 2, "504/Gateway Time-out", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S01_ClinicalTrials_T029f_ClinicalTrialAdvanceSearch_advanceSearch", 50, 50, "400/Bad Request", 50, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
